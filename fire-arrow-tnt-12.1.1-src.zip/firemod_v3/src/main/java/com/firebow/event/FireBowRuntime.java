package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Entity ID dedup
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_DEDUP_WINDOW_MS = 3000L;

    // Position dedup — block cả bow release lẫn arrow tick
    private final Set<BlockPos> recentDone =
        Collections.newSetFromMap(new ConcurrentHashMap<>());

    // Pending rails: pos → [ticksLeft] — đặt rail sau N tick
    private final Map<BlockPos, int[]> pendingRails = new ConcurrentHashMap<>();

    // Pending carts: pos → [ticksLeft, retryCount, syncReady]
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_CART_RETRIES = 8;

    private final TickSynchronizer tickSync = new TickSynchronizer();
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }

    /** Check entity ID dedup. */
    public boolean isDuplicateArrow(int entityId) {
        Long lastMs = acceptedArrows.get(entityId);
        return lastMs != null &&
            (System.currentTimeMillis() - lastMs) < ARROW_DEDUP_WINDOW_MS;
    }

    /** Check position dedup — dùng bởi FireArrowMixin. */
    public boolean wasRecentlyPlaced(BlockPos pos) {
        return recentDone.contains(pos);
    }

    /**
     * Bow release: lên lịch đặt rail sau 1 tick (tránh cancel bow draw),
     * rồi cart sau thêm 2-4 tick nữa.
     */
    public void scheduleBowRelease(BlockPos railPos, int cartDelay) {
        if (recentDone.contains(railPos)) return;
        recentDone.add(railPos);
        // Rail sau 1 tick — arrow packet kịp gửi trước
        pendingRails.put(railPos, new int[]{ 1, cartDelay });
        AsyncRunner.runDelayed(() -> recentDone.remove(railPos), ARROW_DEDUP_WINDOW_MS);
    }

    /**
     * Arrow tick: đặt rail ngay + schedule cart.
     * Chỉ gọi khi !wasRecentlyPlaced().
     */
    public void acceptArrow(int entityId, BlockPos railPos, int cartDelay) {
        if (recentDone.contains(railPos)) return;
        recentDone.add(railPos);
        acceptedArrows.put(entityId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> {
            acceptedArrows.remove(entityId);
            recentDone.remove(railPos);
        }, ARROW_DEDUP_WINDOW_MS);
        pendingCarts.put(railPos, new int[]{ cartDelay, 0, 0 });
    }

    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();
        if (client.player == null || client.world == null) return;
        if (!enabled) {
            pendingRails.clear();
            pendingCarts.clear();
            return;
        }

        // Xử lý pending rails
        Iterator<Map.Entry<BlockPos, int[]>> railIter = pendingRails.entrySet().iterator();
        while (railIter.hasNext()) {
            Map.Entry<BlockPos, int[]> e = railIter.next();
            BlockPos pos    = e.getKey();
            int[] state     = e.getValue(); // [0]=ticksLeft [1]=cartDelay

            state[0]--;
            if (state[0] > 0) continue;
            railIter.remove();

            // Đặt rail — arrow đã được tạo rồi
            SearchResult rail = InventoryUtil.findAny(
                net.minecraft.item.Items.RAIL, net.minecraft.item.Items.POWERED_RAIL);
            SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
            if (rail.isMissing() || cart.isMissing()) continue;

            if (client.interactionManager != null) {
                int saved = client.player.getInventory().selectedSlot;
                client.player.getInventory().selectedSlot = rail.slot;
                InteractionUtil.placeBelow(client, pos);
                client.player.getInventory().selectedSlot = saved;
            }

            // Lên lịch cart
            pendingCarts.put(pos, new int[]{ state[1], 0, 0 });
        }

        // Xử lý pending carts
        Iterator<Map.Entry<BlockPos, int[]>> cartIter = pendingCarts.entrySet().iterator();
        while (cartIter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = cartIter.next();
            BlockPos pos  = entry.getKey();
            int[] state   = entry.getValue();

            if (state[2] == 1) continue; // chờ beforeSync

            state[0]--;
            if (state[0] > 0) continue;

            boolean hasRail =
                client.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                client.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                cartIter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing() && client.interactionManager != null) {
                    int saved = client.player.getInventory().selectedSlot;
                    client.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(client, pos);
                    client.player.getInventory().selectedSlot = saved;
                }
            } else if (state[1] < MAX_CART_RETRIES) {
                state[2] = 1; // fallback to beforeSync
                state[1]++;
            } else {
                cartIter.remove();
            }
        }
    }

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = iter.next();
            BlockPos pos  = entry.getKey();
            int[] state   = entry.getValue();
            if (state[2] != 1) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                iter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing()) {
                    int saved = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(mc, pos);
                    mc.player.getInventory().selectedSlot = saved;
                }
            } else if (state[1] < MAX_CART_RETRIES) {
                state[0] = 1;
                state[2] = 0;
            } else {
                iter.remove();
            }
        }
    }
}
